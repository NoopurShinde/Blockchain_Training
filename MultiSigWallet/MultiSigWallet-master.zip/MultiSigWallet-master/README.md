# Ethereum MultiSigWallet

[MultiSigWalletWithDailyLimit.sol](https://github.com/ConsenSys/MultiSigWallet/blob/master/MultiSigWalletWithDailyLimit.sol) is the exact verified contract currently storing millions in assets:

https://etherscan.io/address/0x851b7f3ab81bd8df354f0d7640efcd7288553419#code

Use Solidity compiler version v0.4.10+commit.f0d539ae and *disable* optimizations to get identical bytecode (except for your own constructor arguments).

This repo is the "original" Gnosis multisig wallet written by @Georgi87 and stil in use by Gnosis. For more information, including frontend code, see https://github.com/Gnosis/MultiSigWallet
